<template> 
<p>메인 페이지입니다.</p>   
</template>
<script setup>
</script>